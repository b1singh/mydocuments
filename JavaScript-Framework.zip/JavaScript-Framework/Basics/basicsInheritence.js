const person=require("./basicsclass")
class pet extends person{
    get location(){
        return "delhi"
    }
    constructor(firstname,lastname){
        super(firstname,lastname)
    }
}
let pet1=new pet("sam","sam")
console.log(pet1.fullname())
console.log(pet1.location)
