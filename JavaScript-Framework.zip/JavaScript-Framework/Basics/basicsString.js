// represent as a string
let day='tuesday'
// find the length 
console.log(day.length)
// slice of string
console.log(day.slice(2,4))
// access the character
console.log(day[2])
// split the string
console.log(day.split("s")[0])
let splitday=day.split("s")
console.log(splitday[1].trim().length)
// find the difference in below str]ing
let date='23'
let nextdate='27'
let diff=parseInt(nextdate)-parseInt(date)
console.log(diff.toString())
// concatenation
let newquote=day+" is funday"
console.log(newquote)
// indexof
let val=newquote.indexOf("day",5)
console.log(val)
// find the day occurance in newquote string
let count=0
let val1=newquote.indexOf("day")
while(val1!=-1){
    count++
    val1=newquote.indexOf("day",val1+1)
}
console.log(count)

