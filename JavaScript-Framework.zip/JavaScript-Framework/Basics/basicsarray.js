// decalartion for an rrays
// 1st method
var marks=Array(5)
marks[0]=1
marks[1]=2
marks[2]=3
marks[3]=4
marks[4]=5
console.log(marks)
// 2nd method
var marks=new Array(10,20,30,40,50)
console.log(marks)
// 3rd method
var marks=[5,4,3,2,1]
// access the varaiable 
console.log(marks[2])
// check the length
console.log(marks.length)
// assigned an element with index
marks[3]=14
console.log(marks)
// push an element at last
marks.push(60)
console.log(marks)
// delete the last element from last
marks.pop()
console.log(marks)
// push an element at first
marks.unshift(100)
console.log(marks)
// find the index of element
console.log(marks.indexOf(100))
// find the elemnet or search the element in an array
console.log(marks.includes(100))
// find the subarray from array
console.log(marks.slice(2,4))
// iterated the array and sum of the array
let sum=0
for(let i=0;i<marks.length;i++){
    sum=sum+marks[i]
    console.log(marks[i])
}
console.log("sum is=",sum)
// above sum also we can performed by inbuild method
let thesum=marks.reduce((sum,totalmarks)=>sum+totalmarks,0)
console.log(thesum)
// create a new array from the score array for only even no
var score=[12,13,14,15,16]
var evenscore=[]
for(let i=0;i<score.length;i++){
    if(score[i]%2==0){
        evenscore.push(score[i])
    }
}
console.log("even array=",evenscore)
// do the above with inbuild method filter
let filtereven=score.filter(score=>score%2==0)
console.log(filtereven)
// map array perform on all element operation
// lets multiple all the evenarray elements by 3
let multiplethreearray=filtereven.map(score1=>score1*3)
console.log(multiplethreearray)
// do in a single way with all three operation
let finalarray=score.filter(score=>score%2==0).map(score=>score*3).reduce((sum,totalsum)=>sum+totalsum,0)
console.log(finalarray)
// sorting
let fruits=["banana","apple","orange","pineapple"]
fruits.sort()
console.log(fruits)
// sort the numbers
let number=[12,3,16,14,10]
number.sort()
console.log(number)
// if the in build method not work then the custom method we can do.
let sortresult=number.sort((a,b)=>a-b)
console.log(sortresult)
// reverse
console.log("reverse o/p")
console.log(fruits.reverse())
console.log(number.reverse())
let reverseresult=number.sort((a,b)=>b-a)
console.log(reverseresult)