module.exports= class person
{
    age=23
    get location(){
        return "canada"
    }
    constructor(firstname, lastname){
        this.firstname=firstname
        this.lastname=lastname
    }
    fullname(){
        console.log(this.firstname+this.lastname)
    }

}
// let Person=new person("Tim","col")
// let Person1=new person("test","singh")
// console.log(Person.age)
// console.log(Person.location)
// console.log(Person.fullname())
// console.log(Person1.fullname())