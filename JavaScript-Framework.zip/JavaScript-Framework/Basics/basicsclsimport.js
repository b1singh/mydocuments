const person=require('./basicsclass')
let Person1=new person("bhupender","singh")
console.log(Person1.fullname()) 