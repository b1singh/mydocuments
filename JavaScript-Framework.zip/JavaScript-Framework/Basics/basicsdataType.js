console.log("hello world")
//  varaible
let a=3
console.log(typeof(a))
let b =3.4
console.log(b)
const c="hello"
console.log(c)
let required=true
console.log(typeof(required))

// null :- with null values
// undefined :- not defined any value

// differece between var and let we can not re decalare the let
 c=a+b
console.log(c)
// true to false
console.log(!required)
