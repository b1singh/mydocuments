// function is a block of code
// var global level/ function level
// let global level/ block level
const greet="morning"
if(1==1){
    const greet="afternoon"
}
function add(a,b){
    const greet="evening"
    return a+b
}
let sumofnum=add(2,3)
console.log(sumofnum)
console.log(greet)
// anonomeous function with out any name
let sumofnumbers=function(a,b){
    return a+b
}
console.log(sumofnumbers(2,3))
// we can also reduce the bit line of code and written a one line function
let sumofnumber=(a,b)=>a+b
console.log(sumofnumber(2,3))
