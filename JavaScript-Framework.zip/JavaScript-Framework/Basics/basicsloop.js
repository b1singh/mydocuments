const flag=true
if(flag){
    console.log("condition stasfied")

} else{
    console.log("not stasfied")
}
// while loop
let i=0
while(i>=10){
    i++;
    console.log(i)
}
// do while

do {
    i++
    console.log(i)
}while(i>=10)
// for loop
for(let k=0;k<=10;k++){
    console.log(k)
}
let required=true
while(required){
    console.log(required)
    required=false
}
// from 1 to 100 give me common multiple value for 2 and 5 print only first three values
let m=0
for( let n=1;n<=100;n++){
    if(n%2==0 && n%5==0){
        m++
        console.log(n)
        if(m>=3){
            break
        }
    }


}