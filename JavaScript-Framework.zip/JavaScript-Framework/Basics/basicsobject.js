let person={
    firstname: 'Tim',
    lastname: 'Joe',
    age:23,
    fullname: function(){
        console.log(this.firstname+this.lastname)
    }

}
console.log(person.fullname())
console.log(person.firstname)
console.log(person['lastname'])
person['firstname']='Tim cruse'
console.log(person.firstname)
person.gender='male'
console.log(person.gender)
delete person.gender
console.log(person)
// serach in properties
let findgender='gender' in person
console.log(findgender)
// traverse the properties
for(let key in person){
    console.log(person[key])
}

