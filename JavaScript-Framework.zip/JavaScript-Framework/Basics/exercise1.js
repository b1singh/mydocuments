let expenses=[10,20,30,40,50]
let amount=0
for(let i =0;i<expenses.length;i++){
    amount=amount+expenses[i]
}
console.log(amount)
let lowsestamount=expenses.sort((a,b)=>a-b)
console.log("lowest is",lowsestamount[0])
let highestamount=expenses.sort((a,b)=>b-a)
console.log("highestamount=",highestamount[0])