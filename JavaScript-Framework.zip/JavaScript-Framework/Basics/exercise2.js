let studentNames=["deepak","pramod","bhupender","arun","mohit"]
studentNames.unshift("newstudent")
console.log("After add new student at begining=",studentNames)
studentNames.pop()
console.log("After remove the last student=",studentNames)
studentNames.sort()
console.log("After alphabatize the array",studentNames)