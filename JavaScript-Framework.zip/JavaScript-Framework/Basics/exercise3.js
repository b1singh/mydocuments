let productPrices=[100,120,110,130,100,150,300]
let discountedPrices=[]
discountedPrices= productPrices.map(productPrices=>productPrices*10/100)
console.log("discounted price",discountedPrices)
let affordableProducts=discountedPrices.filter(discountedPrices=>discountedPrices<50)
console.log("below 50",affordableProducts)
let sumofelement=affordableProducts.reduce((sum,total)=>sum+total,0)
console.log("sum is",sumofelement)

