//Can a JavaScript object hold a function as a property
const person=
{
    name:"john",
    age:25,
    greet:function(){
        console.log("hi my name is",this.name)
    }
}
console.log(person.age)
console.log(person.name)
person.greet()