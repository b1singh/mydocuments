//What are anonymous functions in JavaScript? 
// Define their syntax and implementation.
const person={
    name:"bhupender",
}
function sayhello(){
    return "hello world";
}
const greet= function(name){
    return "hello anonmous "+person.name;
}

const hello=sayhello()
console.log(hello)
console.log(greet())