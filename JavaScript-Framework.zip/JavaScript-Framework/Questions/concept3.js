// var is a function=scoped and global scope and can be re declared and updated
function varExample(){
    var x=1
    if(true){
        var x=2
        console.log(x)
    }
    console.log(x)
}
varExample()
// let is a blocked scope and can be updated but not re declared with in same scope
function letExample(){
    let x=1
    if(true){
        let x=2
        console.log(x)
    }
    console.log(x)
}
letExample()
// const is blocked scope can not be updated or re declared
function constExample(){
    const x=1
    if(true){
        const x=2
        console.log(x)
    }
    console.log(x)
}
constExample()