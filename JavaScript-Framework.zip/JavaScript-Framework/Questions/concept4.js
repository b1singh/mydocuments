//push, pop, slice, shift, and unshift methods 
let fruits=["apple","banana","orange","pineapple"]
// push the element at end
fruits.push("fig")
console.log(fruits)
// pop an element from the end
fruits.pop()
console.log(fruits)
// push the elemnt at start
fruits.unshift("tomato")
console.log(fruits)
// pop an elemt at start
fruits.shift()
console.log(fruits)
let removedFruits=fruits.splice(2.3)
console.log(removedFruits)
// iterate an element
fruits.forEach((fruits,index)=>{
    console.log(`${index}: ${fruits}`)
})
// index of element
console.log(fruits.indexOf("apple"))