// java script Aschronous means its not wait for the step and move to the next step
console.log("1")
console.log("2")
console.log("3")
console.log("4")
console.log("5")
setTimeout(() => {
    console.log("6")
    
}, 2000);
console.log("7")