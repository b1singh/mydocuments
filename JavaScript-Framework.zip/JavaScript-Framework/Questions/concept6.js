function fetchdata(callback){
    setTimeout(() => {
        console.log("data fetched")
        const data="sample data"
        callback(data)
        
    }, 2000);
}
function processeddata(data){
    console.log("processing:",data)
}
function modifyingdata(data){
    console.log("modifiying:",data)
}
fetchdata(processeddata)
fetchdata(modifyingdata)