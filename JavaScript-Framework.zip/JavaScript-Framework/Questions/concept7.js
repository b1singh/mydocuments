 function fetchdata(callback){
    return new Promise((resolve)=>{
        setTimeout(() => {
            console.log("data fetched")
            const data="sample data"
            resolve(data)
            
        }, 2000);

    })
  
}
// promise for resolve the data we can also take the pending and rejected
fetchdata().then(function(data){
    console.log("processing",data)
})