// compare the content only
console.log(5=='5')
// compare the content as well as type
console.log(5==='5')
