// null value object
let a=null
console.log(a)

console.log(typeof(a))

let b
console.log(b)

console.log(typeof(b))