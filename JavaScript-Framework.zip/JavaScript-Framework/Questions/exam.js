let students=[
      {name:"Alice",score:25},
      {name:"Bob",score:55},
      {name:"Charle",score:65},
      {name:"David",score:35},
      {name:"Eve",score:75}
]
//Filters out students who passed in the exam with score more than 36
let scoredmorethan36=students.filter(student=>student.score>=35)
console.log(scoredmorethan36)
//Update passed students names to uppercase
let takeuppercasename=scoredmorethan36.map(student=>student.name.toUpperCase())
console.log(takeuppercasename)
//Total score of all passing students
let totalscore=scoredmorethan36.reduce((sum,student)=>sum+student.score,0)
console.log(totalscore)