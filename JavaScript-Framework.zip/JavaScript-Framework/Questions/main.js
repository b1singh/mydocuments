import student  from "./student.js";

// create an object of student class
const student1=new student("john doe",28,'A')
// call the method to get the student details
console.log(student1.getstudentdetails())