import person from './person.js'
class student extends person{
    constructor(name,age,grade){
        super(name,age)
        this.grade=grade
    }
    // method to get student details
    getstudentdetails(){
        const parentdetails=super.getDetails();
        return `${parentdetails}, Grade:${this.grade}`
    }
}
// Export student class
export default student